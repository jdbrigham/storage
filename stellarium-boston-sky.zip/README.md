
# stellarium-boston-sky

## Deploy
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/import/project)

## Overview
This project embeds the **Stellarium Web Engine**, a JavaScript/WebGL planetarium engine designed to be embedded into websites citeturn1search2turn1search3. Data sources (stars, DSO catalogs, landscapes, Milky Way surveys) follow the wiring demonstrated in the official simple HTML example citeturn1search5.

## Skyline Toggle
A Boston skyline SVG overlay is included under `public/overlays/` and can be toggled independently of the Stellarium landscape layer.
