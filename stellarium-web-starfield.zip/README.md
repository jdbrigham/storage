
# Stellarium Web Engine — Public Starfield Background

This repo is a **ready-to-deploy** static site that renders an **accurate, animated starfield** using the official **Stellarium Web Engine** (JS + WASM) in your browser.

It is designed to deploy on **Netlify**, **Vercel**, **Cloudflare Pages**, or any static host that serves **WASM** correctly. GitHub Pages generally mishandles `.wasm` MIME types and large data trees — use a modern static host for best results.

## Quick start

1. **Get the engine build + data**
   - Clone the official engine repo:
     ```bash
     git clone https://github.com/Stellarium/stellarium-web-engine
     ```
   - Build (or obtain) the JS/WASM pair:
     ```bash
     # requires Emscripten; see upstream README
     source $PATH_TO_EMSDK/emsdk_env.sh
     make js
     # you need: build/stellarium-web-engine.js and build/stellarium-web-engine.wasm
     ```
   - Copy the following into this repo (create folders if missing):
     ```
     vendor/stellarium/stellarium-web-engine.js
     vendor/stellarium/stellarium-web-engine.wasm
     vendor/stellarium/test-skydata/*      # copy from apps/simple-html/test-skydata/
     vendor/stellarium/fonts/Roboto-*.ttf  # copy from apps/simple-html/static/fonts/
     ```

2. **Local preview**
   ```bash
   python -m http.server 8000
   open http://localhost:8000/index.html
   ```

3. **Deploy**
   - **Netlify**: drag‑and‑drop the repo folder, or `netlify deploy --prod`.
   - **Vercel**: `vercel` in the repo directory.
   - **Cloudflare Pages**: connect the repo and use default build (static).
   These hosts serve `.wasm` with the correct `Content-Type: application/wasm` automatically.

## Configure location/time

Open `public/js/config.js` and edit:
```js
export const INITIAL_LOCATION = { lat: 42.3601, lon: -71.0589, elev: 10 };
export const INITIAL_FOV_DEG = 90;
export const INITIAL_SPEED = 30; // seconds of sky time per real second
```
You can also tweak defaults inside `public/index.html`.

## Notes
- Stellarium Web Engine is **AGPL‑3.0** (or available commercially). Ensure license compliance for your use case.
- The example data sources (`test-skydata`) ship in the upstream repo and are referenced exactly as in their sample page.

---

## References
- Stellarium Web Engine (embeddable JS/WebGL planetarium; features + build): see upstream README. 
- Example simple HTML with data sources wiring: see `apps/simple-html/stellarium-web-engine.html` in the upstream repo.
