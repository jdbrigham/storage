
import { INITIAL_LOCATION, INITIAL_FOV_DEG, INITIAL_SPEED } from './config.js';

const canvas = document.getElementById('sky-canvas');
const speedSlider = document.getElementById('speed');
const speedLabel  = document.getElementById('speedLabel');
const pauseBtn    = document.getElementById('pauseBtn');
const nowBtn      = document.getElementById('nowBtn');
const cstBtn      = document.getElementById('cstBtn');
const atmBtn      = document.getElementById('atmBtn');
const landBtn     = document.getElementById('landBtn');
const fovSlider   = document.getElementById('fov');
const fovLabel    = document.getElementById('fovLabel');
const timeInput   = document.getElementById('time');

let timeSpeed = INITIAL_SPEED;
let paused = false;
let stel = null;

function toISO(dt){ return new Date(dt.getTime() - dt.getTimezoneOffset()*60000).toISOString().replace('Z','Z'); }
function updateSpeedLabel(){ const v = parseFloat(speedSlider.value); speedLabel.textContent = (v>=0?'+':'') + v + '×'; timeSpeed = v; }
function updateFovLabel(){ fovLabel.textContent = fovSlider.value + '°'; }
function toggleChip(btn){ const p = btn.getAttribute('aria-pressed')==='true'; btn.setAttribute('aria-pressed', String(!p)); return !p; }

if (typeof window.StelWebEngine !== 'function'){
  console.error('Stellarium Web Engine not found. Place JS/WASM under /vendor/stellarium/.');
}

window.StelWebEngine && StelWebEngine({
  wasmFile: '/vendor/stellarium/stellarium-web-engine.wasm',
  canvas,
  onReady(engine){
    stel = engine;
    const base = '/vendor/stellarium/test-skydata/';
    const core = stel.core;
    core.stars.addDataSource({ url: base + 'stars' });
    core.skycultures.addDataSource({ url: base + 'skycultures/western', key: 'western' });
    core.dsos.addDataSource({ url: base + 'dso' });
    core.landscapes.addDataSource({ url: base + 'landscapes/guereins', key: 'guereins' });
    core.milkyway.addDataSource({ url: base + 'surveys/milkyway' });
    core.minor_planets.addDataSource({ url: base + 'mpcorb.dat', key: 'mpc_asteroids' });
    core.planets.addDataSource({ url: base + 'surveys/sso/moon', key: 'moon' });
    core.planets.addDataSource({ url: base + 'surveys/sso/sun', key: 'sun' });
    core.planets.addDataSource({ url: base + 'surveys/sso/moon', key: 'default' });
    core.comets.addDataSource({ url: base + 'CometEls.txt', key: 'mpc_comets' });
    core.satellites.addDataSource({ url: base + 'tle_satellite.jsonl.gz', key: 'jsonl/sat' });

    core.observer.setLocation(INITIAL_LOCATION.lat, INITIAL_LOCATION.lon, INITIAL_LOCATION.elev);
    const now = new Date();
    core.observer.setDate(now.toISOString());
    timeInput.value = toISO(now).slice(0,19);

    if (core.view && typeof core.view.setFov === 'function') {
      core.view.setFov(INITIAL_FOV_DEG * Math.PI/180);
    }
    core.atmosphere.visible = true;

    let last = performance.now();
    function frame(ts){
      const dt = (ts - last)/1000; last = ts;
      if (stel && !paused && timeSpeed !== 0){
        const cur = new Date(timeInput.value);
        cur.setSeconds(cur.getSeconds() + dt * timeSpeed);
        core.observer.setDate(cur.toISOString());
        timeInput.value = toISO(cur).slice(0,19);
      }
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);

    speedSlider.value = String(INITIAL_SPEED);
    speedSlider.addEventListener('input', updateSpeedLabel); updateSpeedLabel();

    fovSlider.value = String(INITIAL_FOV_DEG);
    fovSlider.addEventListener('input', ()=>{ updateFovLabel(); if (core.view?.setFov) core.view.setFov(parseFloat(fovSlider.value)*Math.PI/180); });
    updateFovLabel();

    pauseBtn.addEventListener('click', ()=>{ paused = toggleChip(pauseBtn); });
    nowBtn.addEventListener('click', ()=>{ const n = new Date(); core.observer.setDate(n.toISOString()); timeInput.value = toISO(n).slice(0,19); });
    timeInput.addEventListener('change', ()=>{ const d = new Date(timeInput.value); if (!isNaN(d)) core.observer.setDate(d.toISOString()); });

    cstBtn.addEventListener('click', ()=>{ const val = toggleChip(cstBtn); core.constellations.lines_visible = val; });
    atmBtn.addEventListener('click', ()=>{ const val = toggleChip(atmBtn); core.atmosphere.visible = val; });
    landBtn.addEventListener('click', ()=>{ const val = toggleChip(landBtn); core.landscapes.visible = val; });

    function resize(){
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas.getBoundingClientRect();
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      if (stel.setPixelRatio) stel.setPixelRatio(dpr);
    }
    resize();
    window.addEventListener('resize', resize);
  }
});
