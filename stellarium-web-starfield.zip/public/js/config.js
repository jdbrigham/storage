
export const INITIAL_LOCATION = { lat: 42.3601, lon: -71.0589, elev: 10 };
export const INITIAL_FOV_DEG = 90;
export const INITIAL_SPEED = 30; // seconds sky-time per real second
